import React ,{useState} from 'react'
import AsyncStorage from "@react-native-async-storage/async-storage"


const umObjeto = {
  id: "1",
  titulo: "Um título",
  texto: "Um texto qualquer"
}